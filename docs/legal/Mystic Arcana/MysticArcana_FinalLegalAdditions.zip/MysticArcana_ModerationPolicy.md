# Mystic Arcana Moderation & Conduct Enforcement Policy  
*Effective Date: [Insert Date]*

To keep Mystic Arcana safe and sacred, we enforce clear standards for moderation and platform safety.

## 1. What We Moderate
We review and may remove:
- Inappropriate journal entries if shared publicly  
- Abusive or misleading AI card content  
- Disrespectful behavior toward guides/readers  
- Spam, scams, or impersonation

## 2. How We Moderate
- Reports are reviewed within 48 hours  
- Content flagged by AI may trigger a manual review  
- Human moderators follow clear guidelines of empathy and fairness

## 3. Enforcement Actions
- Warning  
- Temporary account suspension  
- Permanent ban  
- In cases of harm or harassment: report to authorities

## 4. Appeals
You may appeal content or account actions at **admin@mysticarcana.com**

---

We believe in second chances and conscious growth—but safety comes first.