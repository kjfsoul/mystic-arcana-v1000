# Mystic Arcana Festival Vendor / Brand Partner Agreement  
*Effective Date: [Insert Date]*

This agreement governs promotional partnerships between Mystic Arcana and external vendors, sponsors, or collaborators.

## 1. Partnership Scope
Partners may:
- Have products featured in Mystic Arcana's shop or blog  
- Co-host readings, events, or livestreams  
- Provide discount codes or affiliate links

## 2. Responsibilities
Partners agree to:
- Provide accurate product info and timely fulfillment  
- Align offerings with Mystic Arcana's values (no fear-based marketing, inclusive tone)  
- Respect user privacy and avoid aggressive upsells

## 3. Brand Usage
- Mystic Arcana logos or branding may only be used with written approval  
- Partners may be promoted using affiliate tools with attribution

## 4. Termination
Partnership may be ended at any time for:
- Brand misalignment  
- User complaints or misconduct  
- Breach of terms

For partnership proposals or issues: **admin@mysticarcana.com**