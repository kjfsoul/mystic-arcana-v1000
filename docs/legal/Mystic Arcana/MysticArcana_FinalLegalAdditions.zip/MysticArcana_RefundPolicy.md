# Mystic Arcana Refund & Return Policy  
*Effective Date: [Insert Date]*

Mystic Arcana offers digital services and occasionally physical items such as printed tarot cards or spiritual tools.

## 1. Digital Content
- All digital purchases (e.g. AI readings, birth charts) are non-refundable once delivered.  
- If technical errors prevent access to your content, contact **admin@mysticarcana.com** within 7 days for resolution.

## 2. Physical Products
Refunds are available for physical products that are:
- Defective or misprinted
- Incorrect (wrong item shipped)

To initiate a return:
- Email support with your order number, photo evidence (if applicable), and your request  
- We will respond within 3 business days

## 3. Non-Returnable Items
- Personalized card decks or tools printed based on user input  
- Used or altered ritual tools

## 4. Exchange Policy
We do not offer exchanges. Please place a new order if you want a replacement.

## 5. Shipping & Timing
- Return shipping is the responsibility of the buyer  
- Refunds will be processed back to the original payment method within 7–10 days once the return is approved