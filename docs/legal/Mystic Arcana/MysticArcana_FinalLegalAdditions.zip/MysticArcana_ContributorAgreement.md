# Mystic Arcana Reader & Contributor Agreement  
*Effective Date: [Insert Date]*

This agreement governs the relationship between Mystic Arcana and third-party readers, astrologers, writers, and content contributors.

## 1. Contributor Expectations
Contributors agree to:
- Deliver accurate, respectful, and inclusive content  
- Avoid using fear-based or manipulative tactics in interpretations  
- Represent the Mystic Arcana brand professionally

## 2. Compensation
- Contributors may be paid per session, per post, or via revenue share  
- Payment terms will be outlined in your specific scope of work

## 3. Ownership & Licensing
- Mystic Arcana retains the right to display, distribute, and archive contributed content  
- Contributors may request credit or anonymity based on personal preference

## 4. Confidentiality
- All user data and platform materials accessed during contribution are confidential

## 5. Termination
We reserve the right to end contributor agreements at any time due to:
- Brand misalignment  
- Community conduct violations  
- Inactivity

For questions or contributor support: **admin@mysticarcana.com**